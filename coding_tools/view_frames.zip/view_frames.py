import os, glob
import Tkinter as tk
from PIL import Image, ImageTk
import math

def reorder_names(imagenames, form):
    ff = form.split("?")
    results = []
    for i,val in enumerate(imagenames):
        _,_,rest = val.partition(ff[0])
        result,_,_ = rest.partition(ff[1])
        results.append(int(result))
    sresult = sorted(range(len(results)), key=lambda k: results[k])
    names = [imagenames[i] for i in sresult]
    numbers = [results[i] for i in sresult]
    return names, numbers

class Frames(object):
    def __init__(self, globentry, form, foldername):
        print(foldername)
        self.foldername = foldername
        self.active = 0
        imagenames = glob.glob(self.foldername + '\\' + globentry)
        self.imagenames, self.imagenumbers = reorder_names(imagenames, form)
        
    def make_win(self, win):
        self.active = 1
        self.img = Image.open(self.imagenames[0])
        self.img = self.img.resize((320,240))
        self.canvas = tk.Canvas(win, bg="black")
        self.canvas.pack(fill=tk.BOTH, expand = 1)
        self.tkimg = ImageTk.PhotoImage(self.img)
        self.cimg = self.canvas.create_image(0,0,image=self.tkimg, anchor = tk.NW)
    
    def load_image(self, imagenumber):
        if imagenumber in self.imagenumbers:
            idx = self.imagenumbers.index(imagenumber)
            self.img = Image.open(self.imagenames[idx])
            iwidth,iheight = self.img.size
            iratio = iheight/float(iwidth)
            cwidth = self.canvas.winfo_width()
            cheight =int(math.floor(cwidth*iratio))
            #print(cwidth,cheight,iratio,iwidth,iheight)
            #print(type(cwidth),type(cheight))
            self.img = self.img.resize((cwidth,cheight))
            self.tkimg = ImageTk.PhotoImage(self.img)
            self.canvas.itemconfig(self.cimg, image=self.tkimg)
            
class App(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.configure(background = "black")
        self.frame1 = tk.Frame(self, bg = "black")
        self.frame2 = tk.Frame(self, bg = "black")
        self.frame1.pack(side=tk.LEFT, fill=tk.Y, expand=1)
        self.frame2.pack(side=tk.RIGHT, fill=tk.Y, expand=1)
        
        tk.Label(self.frame1, text = "Enter Glob", bg = "#115599", fg = "white").pack(padx=3,pady=3,anchor=tk.W,fill=tk.X,expand=1)
        self.globentry = tk.Entry(self.frame1, bg = "black", fg = "white")
        self.globentry.pack()
        self.globentry.insert(0, "*[!seg].jpg")
        self.form = tk.Entry(self.frame1, bg = "black", fg = "white")
        self.form.pack()
        self.form.insert(0, "img_?.jpg")
        self.filesep = '\\'
        files = os.listdir('.')
        
        self.folders = [i for i in files if os.path.isdir(i)]
        self.cb_vars = []
        self.cb_folders = []
        self.frames_obj = [Frames(self.globentry.get(), self.form.get(), i) for i in self.folders]
        for i,f in enumerate(self.folders):
            self.cb_vars.append(tk.IntVar())
            self.cb_folders.append(tk.Checkbutton(self.frame1, text = f, variable=self.cb_vars[i],selectcolor="orange", bg="black", activebackground="black", fg="white", activeforeground="white"))
            self.cb_folders[i].pack(anchor=tk.W)
    
        self.ok_button = tk.Button(self.frame1, text="OK", bg = "#115599", fg = "white", command=self.ok_button_callback)
        self.ok_button.pack()
        self.scale = tk.Scale(self.frame2, orient=tk.VERTICAL, from_=0, to_=100, bg="black", fg="white", highlightthickness=0)
        self.scale.bind("<ButtonRelease-1>", self.scale_callback)
        self.scale.pack(fill = tk.Y, expand = 1)
        self.windows_loaded = 0
        
        self.bind("<Right>", self.next_image)
        self.bind("<Left>", self.prev_image)
        self.idx = 0
    
    def next_image(self,event):
        if self.windows_loaded:
            if self.idx < self.uilen:
                self.idx += 1
                pos = math.floor(self.idx/self.uilen*100)
                self.scale.set(pos)
                self.update_images()
        
    def prev_image(self,event):
        if self.windows_loaded:
            if self.idx > 0:
                self.idx -= 1
                self.update_images()
    
    def ok_button_callback(self):
        self.load_windows()
    
    def scale_callback(self,event):
        if self.windows_loaded:
            self.idx = int(math.ceil((self.scale.get()/100)*self.uilen))
            self.update_images()
            
    def update_images(self):
        for f in self.frames_obj:
            if f.active:
                #print(self.idx)
                f.load_image(self.uniqueimages[self.idx])
        
    def load_windows(self):
        
        self.idx = 0
        list_of_sets = []

        offsetx = 300
        offsety = 0
        for i in range(0,len(self.cb_vars)):
            if self.cb_vars[i].get():
                if len(self.frames_obj[i].imagenumbers) > 0:
                    self.windows_loaded = 1
                    list_of_sets.append(set(self.frames_obj[i].imagenumbers)) # turn list into set
                    self.win = tk.Toplevel(self)
                    self.win.title(self.folders[i])
                    offsetx += 50
                    offsety += 25
                    self.win.geometry('320x240+%d+%d' % (offsetx,offsety))
                    self.win.bind("<Right>", self.next_image)
                    self.win.bind("<Left>", self.prev_image)
                    self.frames_obj[i].make_win(self.win)
        if self.windows_loaded:
            self.uniqueimages = sorted(list(set.union(*list_of_sets))) # union of sets, convert to list, and sort
            self.uilen = len(self.uniqueimages)-1
        
app = App()
app.update()
aw = app.winfo_width()
ah = app.winfo_height()
app.geometry('%dx%d+0+0' % (aw,ah))
app.mainloop()