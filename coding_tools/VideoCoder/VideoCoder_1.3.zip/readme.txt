Open the folder containing the VideoCoder.jar folder.

Hold Shift key and Right-click inside this folder
In the context menu, click "Open Command Window Here"

Alternatively, go to Start, type "commmand prompt" and Press enter to launch command prompt.
Type "cd path_to_video_program_folder", e.g.
cd c:\users\sbf\desktop\VideoCoder_1.3

Java Runtime Enviroment is required to run this program. If you type "java -version" into command prompt, you should see some text output on the screen.
If you get a "not recognized as an internal or external command", you need to add the folder containing java.exe to your environment variable path. Please seek instructions on how to do this online.

Still in command prompt, type the following and press Enter to launch the coding program
java -jar VideoCoder.jar config.xml